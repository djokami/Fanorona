package fanorona_prog06;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

public class Tuto_menu_toggle {

    @FXML
    private AnchorPane tuto_menu;

    @FXML
    private Text tuto_title;

    @FXML
    private Button return_to_main;

    @FXML
    private Button rules_btn;

    @FXML
    private Button how_to_btn;

    @FXML
    void return_to_main(ActionEvent event) {

    }

    @FXML
    void rules_btn(ActionEvent event) {

    }

}
