package Modele;


public enum EnumDirection {  
    Bas, Haut, Droite, Gauche, BasGauche, BasDroite, HautGauche, HautDroite, Erreur, Inconnue;
}